<?php
function IsNullOrEmptyString($str){
    return ($str === null || trim($str) === '');
}
?>